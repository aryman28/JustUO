using System; 
using System.Collections; 
using Server; 
using Server.Items; 
using Server.Network; 
using Server.Spells; 
using Server.Spells.Msciciel; 
using Server.Prompts;
using Server.Targeting; 
 using Server.Gumps;

namespace Server.Gumps
{
    public class MscicielBookGump : Gump
    {
        private MscicielBook m_Book;

        int gth = 0x903;

        private void AddBackground()
        {
            AddPage(0);
            AddImage(100, 10, 0x89B, 0);
        }

        public static bool HasSpell(Mobile from, int spellID)
        {
            Spellbook book = Spellbook.Find(from, spellID);
            return (book != null && book.HasSpell(spellID));
        }

        public MscicielBookGump(Mobile from, MscicielBook book) : base(150, 200)
        {
            m_Book = book;
            AddBackground();
            AddPage(1);
            AddLabel(150, 17, gth, "Um. M�ciciela");
            int sbtn = 0x93A;
            int sbtn1 = 0x7585;
            int dby = 40;
            int dbpy = 40;
            AddButton(396, 14, 0x89E, 0x89E, 17, GumpButtonType.Page, 2);

            AddButton(283, 179, sbtn1, sbtn1, 19, GumpButtonType.Reply, 0);
            AddLabel(306, 181, 0, @"Poka� pasek zakl��");

            if (HasSpell(from, 251))
            {
                AddLabel(145, dbpy, gth, "Duszenie");
                AddButton(125, dbpy + 3, sbtn, sbtn, 1, GumpButtonType.Reply, 1);
                dby = dby + 20;
            }
            if (HasSpell(from, 252))
            {
                AddLabel(145, dby, gth, "Furia");
                AddButton(125, dby + 3, sbtn, sbtn, 2, GumpButtonType.Reply, 1);
                dby = dby + 20;
            }
            if (HasSpell(from, 253))
            {
                AddLabel(145, dby, gth, "Leczenie Ran");
                AddButton(125, dby + 3, sbtn, sbtn, 3, GumpButtonType.Reply, 1);
                dby = dby + 20;
            }
            if (HasSpell(from, 254))
            {
                AddLabel(145, dby, gth, "Mroczny Kie�");
                AddButton(125, dby + 3, sbtn, sbtn, 4, GumpButtonType.Reply, 1);
                dby = dby + 20;
            }
            if (HasSpell(from, 255))
            {
                AddLabel(145, dby, gth, "Po�wi�cona Bro�");
                AddButton(125, dby + 3, sbtn, sbtn, 5, GumpButtonType.Reply, 1);
                dby = dby + 20;
            }
            if (HasSpell(from, 256))
            {
                AddLabel(145, dby, gth, "Przekl�ta Bro�");
                AddButton(125, dby + 3, sbtn, sbtn, 6, GumpButtonType.Reply, 1);
                dby = dby + 20;
            }
            if (HasSpell(from, 257))
            {
                AddLabel(145, dby, gth, "Przyw. Umar�ych");
                AddButton(125, dby + 3, sbtn, sbtn, 7, GumpButtonType.Reply, 1);
                dby = dby + 20;
            }
            if (HasSpell(from, 258))
            {
                AddLabel(145, dby, gth, "Zemsta");
                AddButton(125, dby + 3, sbtn, sbtn, 8, GumpButtonType.Reply, 1);
            }

            int i = 2;

            if (HasSpell(from, 251))
            {
                AddPage(i);
                AddButton(396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, i + 1);
                AddButton(123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, i - 1);
                AddLabel(150, 37, gth, "Duszenie");
                AddHtml(130, 59, 123, 132, "Przeciwnik Dusi si� i traci zdrowie.", false, false);
                AddLabel(295, 60, gth, "Min. Umiej. : 65");
                AddLabel(295, 80, gth, "Min. Mana: 29");
                i++;
            }

            if (HasSpell(from, 252))
            {
                AddPage(i);
                AddButton(396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, i + 1);
                AddButton(123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, i - 1);
                AddLabel(150, 37, gth, "Furia");
                AddHtml(130, 59, 123, 132, "Twoje ataki s� szybsze oraz bardziej celne.", false, false);
                AddLabel(295, 60, gth, "Min. Umiej. : 25");
                AddLabel(295, 80, gth, "Min. Mana: 15");
                i++;
            }

            if (HasSpell(from, 253))
            {
                AddPage(i);
                AddButton(396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, i + 1);
                AddButton(123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, i - 1);
                AddLabel(150, 37, gth, "Leczenie Ran");
                AddHtml(130, 59, 123, 132, "Leczysz swoje rany i regenerujesz zdrowie", false, false);
                AddLabel(295, 60, gth, "Min. Umiej. : 0");
                AddLabel(295, 80, gth, "Min. Mana: 10");
                i++;
            }

            if (HasSpell(from, 254))
            {
                AddPage(i);
                AddButton(396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, i + 1);
                AddButton(123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, i - 1);
                AddLabel(150, 37, gth, "Mroczny Kie�");
                AddHtml(130, 59, 123, 132, "Zadajesz �rednie obra�enia.", false, false);
                AddLabel(295, 60, gth, "Min. Umiej. : 30");
                AddLabel(295, 80, gth, "Min. Mana: 15");
                i++;
            }

            if (HasSpell(from, 255))
            {
                AddPage(i);
                AddButton(396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, i + 1);
                AddButton(123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, i - 1);
                AddLabel(150, 37, gth, "Po�wi�cona Bro�");
                AddHtml(130, 59, 123, 132, "Zadajesz wi�ksze obra�enia atakuj�c najni�sz� odporno�� wroga.", false, false);
                AddLabel(295, 60, gth, "Min. Umiej. : 30");
                AddLabel(295, 80, gth, "Min. Mana: 15");
                i++;
            }

            if (HasSpell(from, 256))
            {
                AddPage(i);
                AddButton(396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, i + 1);
                AddButton(123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, i - 1);
                AddLabel(150, 37, gth, "Przekl�ta Bro�");
                AddHtml(130, 59, 123, 132, "Podczas zadawania obra�e� odzyskujesz zdrowie.", false, false);
                AddLabel(295, 60, gth, "Min. Umiej. : 5");
                AddLabel(295, 80, gth, "Min. Mana: 25");
                i++;
            }

            if (HasSpell(from, 257))
            {
                AddPage(i);
                AddButton(396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, i + 1);
                AddButton(123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, i - 1);
                AddLabel(150, 37, gth, "Przywo�anie Umar�ych");
                AddHtml(130, 59, 123, 132, "Przywo�uje stworzenie umar�ych do pomocy w walce.", false, false);
                AddLabel(295, 60, gth, "Min. Umiej. : 40");
                AddLabel(295, 80, gth, "Min. Mana: 33");
                i++;
            }

            if (HasSpell(from, 258))
            {
                AddPage(i);
                AddButton(396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, i + 1);
                AddButton(123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, i - 1);
                AddLabel(150, 37, gth, "Zemsta");
                AddHtml(130, 59, 123, 132, "Przez kr�tk� chwil� dostajesz premie do obra�e� zale�n� od liczby pobliskich zmar�ych.", false, false);
                AddLabel(295, 60, gth, "Min. Umiej. : 30");
                AddLabel(295, 80, gth, "Min. Mana: 28");
            }
        }

        public override void OnResponse(NetState sender, RelayInfo info)
        {
            Mobile from = sender.Mobile;

            if (from == null)
                return;

            switch (info.ButtonID)
            {
                case 1:
                    {
                        Spell spell = new DuszenieSpell(from, null);
                        spell.Cast();
                        from.SendGump(new MscicielBookGump(from, m_Book));
                        break;
                    }
                case 2:
                    {
                        Spell spell = new FuriaSpell(from, null);
                        spell.Cast();
                        from.SendGump(new MscicielBookGump(from, m_Book));
                        break;
                    }
                case 3:
                    {
                        Spell spell = new LeczenieRanSpell(from, null);
                        spell.Cast();
                        from.SendGump(new MscicielBookGump(from, m_Book));
                        break;
                    }
                case 4:
                    {
                        Spell spell = new MrocznyKielSpell(from, null);
                        spell.Cast();
                        from.SendGump(new MscicielBookGump(from, m_Book));
                        break;
                    }
                case 5:
                    {
                        Spell spell = new PoswieconaBronSpell(from, null);
                        spell.Cast();
                        from.SendGump(new MscicielBookGump(from, m_Book));
                        break;
                    }
                case 6:
                    {
                        Spell spell = new PrzekletaBronSpell(from, null);
                        spell.Cast();
                        from.SendGump(new MscicielBookGump(from, m_Book));
                        break;
                    }
                case 7:
                    {
                        Spell spell = new PrzywolanieUmarlychSpell(from, null);
                        spell.Cast();
                        from.SendGump(new MscicielBookGump(from, m_Book));
                        break;
                    }
                case 8:
                    {
                        Spell spell = new ZemstaSpell(from, null);
                        spell.Cast();
                        from.SendGump(new MscicielBookGump(from, m_Book));
                        break;
                    }
                case 19:
                    {
                        from.SendMessage("Pokazuj� pasek M�ciciela");
                        //from.SendGump(new MscicielSpellBookGump(from));
                        from.SendGump(new MscicielBookGump(from, m_Book));
                        break;
                    }
            }
        }
    }
}
